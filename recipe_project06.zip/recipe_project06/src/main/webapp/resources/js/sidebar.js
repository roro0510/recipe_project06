function toggleSidebar(ref) {
        ref.classList.toggle('active');
        document.getElementById('sidebar').classList.toggle('active');
    }